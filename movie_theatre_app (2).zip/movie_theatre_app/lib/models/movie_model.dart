class MovieModel {
  late int id;
  late int vote_count;
  late var vote_average;
  late String title;
  late String release_date;
  late String original_language;
  late String original_title;
  late List<dynamic> genre_ids;
  late String backdrop_path;
  late String overview;
  late String poster_path;
  late double popularity;
  late String media_type;

  // Named Constructor
  MovieModel.fromJson(Map<String, dynamic> parsedJson) {
    id = parsedJson['id'];
    vote_count = parsedJson['vote_count'];
    vote_average = parsedJson['vote_average'];
    title = parsedJson['title'];
    release_date = parsedJson['release_date'];
    original_language = parsedJson['original_language'];
    original_title = parsedJson['original_title'];
    genre_ids = parsedJson['genre_ids'];
    backdrop_path = parsedJson['backdrop_path'];
    overview = parsedJson['overview'];
    poster_path = parsedJson['poster_path'];
    popularity = parsedJson['popularity'];
    media_type = parsedJson['media_type'];
  }

  // Define the [] operator to access a property of the movie
  dynamic operator [](String property) {
    switch (property) {
      case 'id':
        return id;
      case 'title':
        return title;
      case 'overview':
        return overview;
      case 'poster_path':
        return poster_path;
      default:
        return null;
    }
  }
}
class Movie {
  final int id;
  final String title;
  final String overview;
  final String posterPath;

  Movie({
    required this.id,
    required this.title,
    required this.overview,
    required this.posterPath,
  });

  // Define the [] operator to access a property of the movie
  dynamic operator [](String property) {
    switch (property) {
      case 'id':
        return id;
      case 'title':
        return title;
      case 'overview':
        return overview;
      case 'poster_path':
        return posterPath;
      default:
        return null;
    }
  }
}
