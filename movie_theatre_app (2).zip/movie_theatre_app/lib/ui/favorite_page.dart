import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:movie_theatre_app/models/movie_model.dart';
import 'package:movie_theatre_app/ui/components/movie_card.dart';
import 'package:movie_theatre_app/utils/size_config.dart';
import 'package:movie_theatre_app/utils/ui_text.dart';
import 'package:movie_theatre_app/services/movie_api.dart';

import 'movie_detail_page.dart';

class FavoritePage extends StatefulWidget {
  const FavoritePage({Key? key}) : super(key: key);

  static Widget create(BuildContext context) {
    return FavoritePage();
  }

  @override
  State<FavoritePage> createState() => _FavoritePageState();
}

class _FavoritePageState extends State<FavoritePage> {
  late Future<List<MovieModel>> _favoriteMoviesFuture;

  @override
  void initState() {
    super.initState();
    _favoriteMoviesFuture = _getFavoriteMovies();
  }

  Future<List<MovieModel>> _getFavoriteMovies() async {
    final movieApi = MovieApi();
    final favoriteMovies = await movieApi.getFavoriteMovies();
    return favoriteMovies;
  }

  @override
  Widget build(BuildContext context) {
    return _buildContents(context);
  }

  Widget _buildContents(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: FutureBuilder<List<MovieModel>>(
        future: _favoriteMoviesFuture,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final favoriteMovies = snapshot.data!;
            return CustomScrollView(
              physics: BouncingScrollPhysics(),
              slivers: [
                SliverAppBar(
                  elevation: 0,
                  centerTitle: true,
                  backgroundColor:
                  Theme.of(context).appBarTheme.backgroundColor,
                  expandedHeight: SizeConfig.screenHeight! * 0.10,
                  floating: true,
                  pinned: true,
                  flexibleSpace: FlexibleSpaceBar(
                    centerTitle: false,
                    title: Text(
                      "Favorite",
                      style: TextStyle(
                        color: Theme.of(context).textTheme.bodyText1?.color,
                      ),
                    ),
                  ),
                ),
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                        (BuildContext context, int index) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  MovieDetailPage(movie: favoriteMovies[index]),
                            ),
                          );
                        },
                        child: MovieCard(movie: favoriteMovies[index]),
                      );
                    },
                    childCount: favoriteMovies.length,
                  ),
                ),
              ],
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text("Error: ${snapshot.error}"),
            );
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}
The F