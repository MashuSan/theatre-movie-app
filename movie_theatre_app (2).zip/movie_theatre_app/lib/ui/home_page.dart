import 'package:flutter/material.dart';
import '../models/movie_item.dart';
import '../models/movie_model.dart';
import '../utils/movie_api_provider.dart';
import 'movie_detail_page.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  MoviesApiProvider moviesApiProvider = MoviesApiProvider();
  MovieItem _currentTab = MovieItem.movie;
  late List<dynamic> _trendingMovies;

  final Map<MovieItem, GlobalKey<NavigatorState>> navigatorKeys = {
    MovieItem.movie: GlobalKey<NavigatorState>(),
    MovieItem.favorite: GlobalKey<NavigatorState>(),
  };

  Map<MovieItem, WidgetBuilder> get widgetBuilders {
    return {
      //MovieItem.movie: (context) => MoviePage.create(context),
      //MovieItem.favorite: (context) => FavoritePage.create(context),
    };
  }

  void _selectTab(MovieItem tabItem) {
    if (tabItem == _currentTab) {
      navigatorKeys[tabItem]?.currentState?.popUntil((route) => route.isFirst);
    } else {
      setState(() {
        _currentTab = tabItem;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(centerTitle: true, title: const Text('My movies')),
      body: FutureBuilder(
        future: moviesApiProvider.fetchTrendingMovies(),
        builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
          if (snapshot.hasData) {
            _trendingMovies = snapshot.data;
            return ListView.builder(
              itemCount: _trendingMovies.length,
              itemBuilder: (BuildContext context, int index) {
                final movie = _trendingMovies[index];

                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => MovieDetailPage(
                            movie: Movie(id: movie['id'], title: movie['title'], overview: movie['overview'], posterPath: movie['poster_path']), context: context),
                      ),
                    );
                  },
                  child: ListTile(
                    leading: Image.network(
                      'https://image.tmdb.org/t/p/w92${movie['poster_path']}',
                    ),
                    title: Text(movie['title']),
                  ),
                );
              },
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text(snapshot.error.toString()),
            );
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),
    );
  }
}