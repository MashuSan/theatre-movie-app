import 'package:flutter/cupertino.dart';

import '../utils/consts.dart';
import '../models/movie_item.dart';

class TabScaffold extends StatelessWidget {
  const TabScaffold({
    Key? key,
    required this.currentTab,
    required this.onSelectTab,
    required this.widgetBuilders,
    required this.navigatorKeys,
  }) : super(key: key);

  final MovieItem? currentTab;
  final ValueChanged<MovieItem> onSelectTab;
  final Map<MovieItem, WidgetBuilder> widgetBuilders;
  final Map<MovieItem, GlobalKey<NavigatorState>> navigatorKeys;

  @override
  Widget build(BuildContext context) {
    return CupertinoTabScaffold(
      tabBar: CupertinoTabBar(
        items: [
          _buildItem(MovieItem.movie),
          _buildItem(MovieItem.favorite),
        ],
        onTap: (index) => onSelectTab(MovieItem.values[index]),
      ),
      tabBuilder: (context, index) {
        final item = MovieItem.values[index];
        return CupertinoTabView(
          navigatorKey: navigatorKeys[item],
          builder: (context) => widgetBuilders[item]!(context) ,

        );
      },
    );
  }

  BottomNavigationBarItem _buildItem(MovieItem tabItem) {
    final itemData = Consts.allTabs[tabItem];
    //final color = currentTab == tabItem ? mainColor : inactiveColor;
    return BottomNavigationBarItem(
      icon: Icon(
        itemData?.icon,
        //color: color,
      ),
      label: itemData?.title,
    );
  }
}